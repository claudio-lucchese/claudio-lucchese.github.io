#ifndef __THIRD_SCAN_HH
#define __THIRD_SCAN_HH

#include "items.hh" 

template <class T,class T1> 
void third_scan(unsigned int n_part, unsigned int m1, unsigned int min_count, unsigned int max_trans_len, unsigned int no_of_threads);

#endif
